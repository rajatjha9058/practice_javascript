// //t a=0;
// //let b=5;

// //if(a&&b){
// //console.log("ture 1");
// //}else{
// // console.log("false 0");
// //}





// //let d="-32";
// let d=  null
// //let d= -20 
                                                                                                                                                               
// let c = 10;
// if (d) {
//    console.log("truthy value");
// } else {

//    console.log("falsey value");

// }


// // let d = "9"
// console.log(d ? "true" : "false")
// console.log(!d); 

let a="30";
let b="25";
console.log(typeof a ,typeof b)
if(a!=b){
   console.log("true");
      
}else{
   console.log("false");
}
   

